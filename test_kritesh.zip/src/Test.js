import React, { useEffect, useState } from 'react';
import axios from 'axios';

import './index.css';

const movieData = [
  { title: "Once Upon a Time in Hollywood" },
  { title: "Hollywood" },
  { title: "Doc Hollywood" },
  { title: "Hollywood Homicide" },
];

function Test() {
  const [movies, setMovies] = useState([]);
  const [type, setType] = useState("all");
  const [searchQuery, setSearchQuery] = useState('');
  const [showFeed, setShowFeed] = useState(false);
  const [posts, setPosts] = useState([]);
  const [todos, setTodos] = useState([]);
  const [users, setUsers] = useState([]);
  const [comments, setComments] = useState([]);
  const API_KEY = 'dcc773e9';

  // Axios instance for Omdb API
  const omdbApi = axios.create({
    baseURL: 'https://www.omdbapi.com/',
  });

  // Axios instance for JSONPlaceholder API
  const jsonPlaceholderApi = axios.create({
    baseURL: 'https://jsonplaceholder.typicode.com',
  });

  // Fetch movie data from Omdb API
  const fetchMovies = async () => {
    try {
      let promises = [];

      if (type === "all" || type === "movie") {
        const moviePromises = movieData.map(async (movie) => {
          const response = await omdbApi.get(`?apikey=${API_KEY}&t=${encodeURIComponent(movie.title)}&type=movie`);
          return response.data && response.data.Response !== "False"
            ? {
                title: response.data.Title,
                poster: response.data.Poster !== "N/A" ? response.data.Poster : null,
                year: response.data.Year,
                genre: response.data.Genre,
                plot: response.data.Plot,
              }
            : { title: movie.title, error: "Not found" };
        });
        promises = promises.concat(moviePromises);
      }

      if (type === "all" || type === "series") {
        const seriesPromises = movieData.map(async (movie) => {
          const response = await omdbApi.get(`?apikey=${API_KEY}&t=${encodeURIComponent(movie.title)}&type=series`);
          return response.data && response.data.Response !== "False"
            ? {
                title: response.data.Title,
                poster: response.data.Poster !== "N/A" ? response.data.Poster : null,
                year: response.data.Year,
                genre: response.data.Genre,
                plot: response.data.Plot,
              }
            : { title: movie.title, error: "Not found" };
        });
        promises = promises.concat(seriesPromises);
      }

      const movieDetails = await Promise.all(promises);
      setMovies(movieDetails);
    } catch (error) {
      console.error("Error fetching movie details:", error);
    }
  };

  // Fetch post data from JSONPlaceholder API
  const fetchFeedData = async () => {
    try {
      const response = await jsonPlaceholderApi.get('/posts');
      setPosts(response.data);
    } catch (error) {
      console.error("Error fetching feed data:", error);
    }
  };

  // Fetch todo data from JSONPlaceholder API
  const fetchTodoData = async () => {
    try {
      const response = await jsonPlaceholderApi.get('/todos');
      setTodos(response.data);
    } catch (error) {
      console.error("Error fetching ToDo data:", error);
    }
  };

  // Fetch user data from JSONPlaceholder API
  const fetchUsersData = async () => {
    try {
      const response = await jsonPlaceholderApi.get('/users');
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users data:", error);
    }
  };

  // Fetch comment data from JSONPlaceholder API
  const fetchCommentsData = async () => {
    try {
      const response = await jsonPlaceholderApi.get('/comments');
      setComments(response.data);
    } catch (error) {
      console.error("Error fetching comments data:", error);
    }
  };

  // UseEffect hook to fetch data based on selected feed and type
  useEffect(() => {
    if (showFeed === "feed") {
      fetchFeedData();
    } else if (showFeed === "todos") {
      fetchTodoData();
    } else if (showFeed === "users") {
      fetchUsersData();
    } else if (showFeed === "comments") {
      fetchCommentsData();
    } else {
      fetchMovies();
    }
  }, [showFeed, type]);

  // Filter movies based on search query
  const filteredMovies = movies.filter(movie => {
    const query = searchQuery.toLowerCase();
    return (
      (movie.title && movie.title.toLowerCase().includes(query)) ||
      (movie.genre && movie.genre.toLowerCase().includes(query)) ||
      (movie.plot && movie.plot.toLowerCase().includes(query)) ||
      (movie.year && movie.year.toLowerCase().includes(query)) ||
      (movie.error && movie.error.toLowerCase().includes(query))
    );
  });

  // Group comments by postId for easier rendering
  const groupedComments = comments.reduce((acc, comment) => {
    if (!acc[comment.postId]) {
      acc[comment.postId] = [];
    }
    acc[comment.postId].push(comment);
    return acc;
  }, {});

  return (
    <div className="main-container">
      <div className="content-container">
        <div className='d-flex justify-content-end'>
          <div className="task-buttons">
            <button
              className={showFeed === "feed" ? "active" : ""}
              onClick={() => setShowFeed("feed")}
            >
              Post Details
            </button>
            <button
              className={showFeed === "todos" ? "active" : ""}
              onClick={() => setShowFeed("todos")}
            >
              ToDo List
            </button>
            <button
              className={showFeed === "users" ? "active" : ""}
              onClick={() => setShowFeed("users")}
            >
              Users Details
            </button>
            <button
              className={showFeed === "comments" ? "active" : ""}
              onClick={() => setShowFeed("comments")}
            >
              Comments
            </button>
          </div>
        </div>

        <h1 className="main-title">Movies Gallery</h1>
        <p className="subtitle">
          List of movies and TV Shows I have watched till date. Explore what I have watched and feel free to make a suggestion.
        </p>

        <div className='text-center'>
          <input
            type="text"
            placeholder="Search Movie or TV Shows"
            className="search-bar"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="filter-buttons">
          <button
            className={type === "all" ? "active" : ""}
            onClick={() => setType("all")}
          >
            All
          </button>
          <button
            className={type === "movie" ? "active" : ""}
            onClick={() => setType("movie")}
          >
            Movies
          </button>
          <button
            className={type === "series" ? "active" : ""}
            onClick={() => setType("series")}
          >
            TV Shows
          </button>
        </div>

        {showFeed === "comments" ? (
          <div className="feed-container">
            <h2 className='mt-4'>Comments</h2>
            {comments.length > 0 ? (
              <table className="feed-table">
                <thead>
                  <tr>
                    <th>Post ID</th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Body</th>
                  </tr>
                </thead>
                <tbody>
                  {comments.map((comment) => (
                    <tr key={comment.id}>
                      <td>{comment.postId}</td>
                      <td>{comment.id}</td>
                      <td>{comment.name}</td>
                      <td>{comment.email}</td>
                      <td>{comment.body}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div>No comments available</div>
            )}
          </div>
        ) : showFeed === "feed" ? (
          <div className="feed-container">
            <h2 className='mt-4'>Post Details Of User</h2>
            {posts.length > 0 ? (
              <table className="feed-table">
                <thead>
                  <tr>
                    <th style={{ whiteSpace: 'nowrap' }}>User ID</th>
                    <th>Title</th>
                    <th>About Post</th>
                    <th>Post Comments</th>
                  </tr>
                </thead>
                <tbody>
                  {posts.map((post) => {
                    const postComments = groupedComments[post.id] || [];
                    return (
                      <tr key={post.id}>
                        <td>{post.userId}</td>
                        <td>{post.title}</td>
                        <td>{post.body}</td>
                        <td>
                          {postComments.length > 0 ? (
                            <ul>
                              {postComments.map((comment) => (
                                <li key={comment.id}>{comment.body}</li>
                              ))}
                            </ul>
                          ) : (
                            <span>No Comments</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            ) : (
              <div>No posts available</div>
            )}
          </div>
        ) : showFeed === "todos" ? (
          <div className="feed-container">
            <h2 className='mt-4'>ToDo List</h2>
            {todos.length > 0 ? (
              <table className="feed-table">
                <thead>
                  <tr>
                    <th style={{ whiteSpace: 'nowrap' }}>User ID</th>
                    <th>Title</th>
                    <th>Completed</th>
                  </tr>
                </thead>
                <tbody>
                  {todos.map((todo) => (
                    <tr key={todo.id}>
                      <td>{todo.userId}</td>
                      <td>{todo.title}</td>
                      <td>{todo.completed ? "Yes" : "No"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div>No ToDo items available</div>
            )}
          </div>
        ) : showFeed === "users" ? (
          <div className="feed-container">
            <h2 className='mt-4'>User Details</h2>
            {users.length > 0 ? (
              <table className="feed-table">
                <thead>
                  <tr>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id}>
                      <td>{user.id}</td>
                      <td>{user.name}</td>
                      <td>{user.email}</td>
                      <td>{`${user.address.street}, ${user.address.city}, ${user.address.zipcode}`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div>No users available</div>
            )}
          </div>
        ) : (
          <div className="movie-grid">
            {filteredMovies.length > 0 ? (
              filteredMovies.map((movie, index) => (
                <div className="movie-card" key={index}>
                  {movie.poster ? (
                    <img src={movie.poster} alt={movie.title} className="movie-image" />
                  ) : (
                    <div className="movie-placeholder">No Image Available</div>
                  )}
                  <div className="movie-title">{movie.title}</div>
                  {movie.error ? (
                    <div className="movie-error">{movie.error}</div>
                  ) : (
                    <>
                      <div className="movie-year">Year: {movie.year}</div>
                      <div className="movie-genre">Genre: {movie.genre}</div>
                      <p className="movie-plot">{movie.plot}</p>
                    </>
                  )}
                </div>
              ))
            ) : (
              <div className="no-results">No movies or TV shows found.</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Test;
